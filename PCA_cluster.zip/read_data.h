int Remove_file_extension(char *nameout, char *ext, char *filename);
float ** Read_data(char *file_name, int *N, int *N_data,
		   char ***var_names, char ***ind_names,
		   int **select_var);
