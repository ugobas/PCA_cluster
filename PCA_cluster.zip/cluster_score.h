float Cluster_score(int *cluster, int ncl, float **x_VarSam,
		    int Nsam, int Nvar);
