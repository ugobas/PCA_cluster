#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "allocate.h"
#include "read_data.h"

int Count_columns(char *string);
int Read_columns(char *string, int N, float **data, int m_data);
int Read_names(char *string, int N, char **var_names);
int Read_var(char *string, int N, int *variables, char **var_names);

float ** Read_data(char *file_name, int *N, int *N_data,
		   char ***var_names, char ***ind_names,
		   int **select_var)
{
  FILE *file_in=fopen(file_name, "r");
  float **data;
  char string[2000]; int i, m, m_data=0, read_names=0, read_var=0;
  *N=0; *N_data=0;  *ind_names=NULL;

  if(file_in==NULL){
    printf("Error, file %s not found\n", file_name); exit(8);
  }

  while(fgets(string, sizeof(string), file_in)!=0){
    if(string[0]=='#')continue;
    if(*N_data==0)*N=Count_columns(string);
    (*N_data)++;
  }
  fclose(file_in);
  printf(" %d columns of %d lines found in %s\n", *N, *N_data, file_name);

  /* Prepare variables */
  data=malloc((*N)*sizeof(float *));
  for(i=0; i< (*N); i++)data[i]=malloc((*N_data)*sizeof(float));
  *var_names=malloc((*N)*sizeof(char *));
  for(i=0; i< (*N); i++){
    (*var_names)[i]=malloc(500*sizeof(char));
    sprintf((*var_names)[i], "var%d", i+1); 
  }
  *select_var=malloc((*N)*sizeof(int));
  for(i=0; i<(*N); i++)(*select_var)[i]=1;

  i=0; m_data=0;
  file_in=fopen(file_name, "r");
  while(fgets(string, sizeof(string), file_in)!=0){
    if(string[0]=='#'){
      if(strncmp(string, "###", 3)==0){
	if(read_names==0){
	  Read_names(string, *N, *var_names); read_names=1;
	}else if(read_var==0){
	  Read_var(string, *N, *select_var, *var_names); read_var=1; 
	}
      }else if(m_data>0){
	/*if(*ind_names==NULL){
	  *ind_names=malloc((*N_data)*sizeof(char *));
	  for(i=0; i< (*N_data); i++){
	    (*ind_names)[i]=malloc(100*sizeof(char));
	    sprintf((*ind_names)[i], "I%d\0", i+1);
	  }
	}
	sscanf(string+1, "%s", (*ind_names)[m_data-1]);*/
      }
    }else{
      m=Read_columns(string, *N, data, m_data);
      if(m!=*N){
	printf("Error in line %d, %d columns found\n", i+1, m); m_data--;
      }
      m_data++; i++;
    }
  }
  (*N_data)=m_data;
  return(data);
}


int Count_columns(char *string){
  int m=0, read=0;
  char *ptr=string;

  while(*ptr!='\n'){
    if((read==0)&&(*ptr!=' ')&&(*ptr!='\t')){
      read=1; m++;
    }else if(((*ptr==' ')||(*ptr=='\t'))&&(read==1)){
      read=0;
    }
    ptr++;
  }
  return(m);
}


int Read_columns(char *string, int N, float **data, int m_data){
  int m=0, read=0;
  char *ptr=string;

  while(*ptr!='\n'){
    if((read==0)&&(*ptr!=' ')&&(*ptr!='\t')){
      read=1;
      if(m>=N)return(m+1);
      sscanf(ptr, "%f", &(data[m][m_data]));
      m++;
    }else if(((*ptr==' ')||(*ptr=='\t'))&&(read==1)){
      read=0;
    }
    ptr++;
  }
  return(m);
}

int Read_names(char *string, int N, char **var_names){
  int m=0, read=0;
  char *ptr=string+3;

  while(*ptr!='\n'){
    if((read==0)&&(*ptr!=' ')&&(*ptr!='\t')){
      read=1;
      if(m>=N)return(m+1);
      sscanf(ptr, "%s", var_names[m]);
      m++;
    }else if(((*ptr==' ')||(*ptr=='\t'))&&(read==1)){
      read=0;
    }
    ptr++;
  }
  return(m);
}

int Read_var(char *string, int N, int *variables, char **var_names)
{
  int m=0, read=0;
  char *ptr=string+3;

  while(*ptr!='\n'){
    if((read==0)&&(*ptr!=' ')&&(*ptr!='\t')){
      read=1;
      if(m>=N)return(m+1);
      sscanf(ptr, "%d", &variables[m]);
      m++;
    }else if(((*ptr==' ')||(*ptr=='\t'))&&(read==1)){
      read=0;
    }
    ptr++;

  }
  return(m);
}

int Remove_file_extension(char *nameout, char *ext, char *filename){
  char *s1=nameout, *s2=filename;
  while((*s2!='\0')&&(*s2!='.')){*s1=*s2; s1++; s2++;}
  *s1='\0';
  s1=ext;
  while(*s2!='\0'){if(*s1!='.')*s1=*s2; s1++; s2++;} *s1='\0';
  return(0);
}

